/*module Lab3(input clk,input key1,output led1,output buzzer);

reg[25:0] cnt = 0;
reg enable=0, old_key=1;
always@(posedge clk) begin
	cnt <= cnt + 1;
	old_key <= key1;
	if(old_key & ~key1) enable <=~enable;
end
assign led1 = ~(enable & cnt[24]);
assign buzzer = enable & cnt[14];

endmodule 

EX2
module Lab3(input clk, key1, output reg [7:0] seg, output [3:0] dig);
reg [3:0] n = 0;
reg old = 1;

assign dig = 4'b1110;   

// one digit ON

always @(posedge clk) begin
	old <= key1;
	if (old & ~key1) n <= (n==9) ? 0 : n+1;
end

always @*
case(n)
	0: seg = 8'hC0;  1: seg = 8'hF9;
	2: seg = 8'hA4;  3: seg = 8'hB0;
	4: seg = 8'h99;  5: seg = 8'h92;
	6: seg = 8'h82;  7: seg = 8'hF8;
	8: seg = 8'h80;  9: seg = 8'h90;
endcase

endmodule */

module Lab3(input clk, key1, output reg [7:0] seg, output [3:0] dig, output reg led1 = 1);
reg [3:0] n = 0;
reg old = 1;

assign dig = 4'b1110;

always @(posedge clk) begin
	old <= key1;
	if (old & ~key1) n <= (n==9) ? 0 : n+1;
	if (old & ~key1 & n==9) led1 <= ~led1;
end

always @*
case(n)
	0: seg = 8'hC0;  1: seg = 8'hF9;
	2: seg = 8'hA4;  3: seg = 8'hB0;
	4: seg = 8'h99;  5: seg = 8'h92;
	6: seg = 8'h82;  7: seg = 8'hF8;
	8: seg = 8'h80;  9: seg = 8'h90;
	default: seg = 8'hFF;
endcase

endmodule